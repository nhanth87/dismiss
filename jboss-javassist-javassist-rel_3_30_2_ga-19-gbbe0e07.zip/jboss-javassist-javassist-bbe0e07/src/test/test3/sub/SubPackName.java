package test3.sub;

public class SubPackName {
    public static int get() { return 5; } 
}
