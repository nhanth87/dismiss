package test3;

public class SigAttribute<T> {
    T value;
    T get(T t) { return t; }
}
