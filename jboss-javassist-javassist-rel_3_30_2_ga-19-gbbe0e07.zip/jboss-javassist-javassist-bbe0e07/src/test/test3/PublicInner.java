package test3;

class PublicInner2 {
    public static class PS {
        int j;
    }

    int i;
}

public class PublicInner {
    int i;
}
