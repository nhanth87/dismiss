package test1;

public class FieldMod {
    @SuppressWarnings("unused")
    private String text;
    public int i;
}
