/*
 * This is used as a capability for running CtClass#toClass().
 */
package test1;

public class DefineClassCapability {
}
